#include "Lex.h"

void setIn(int pin){

  pinMode(pin, INPUT);

}

void setOut(int pin) {

  pinMode(pin, OUTPUT);

}

void pinHigh(int pin) {

  digitalWrite(pin, HIGH);

}

void pinLow(int pin) {

  digitalWrite(pin, LOW);

}

void time(unsigned long ms) {

  delay(ms);

}

int readPin(int pin) {

  return digitalRead(pin);

}
