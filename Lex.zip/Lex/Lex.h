#ifndef Le_x
#define Le_x

#include <Arduino.h>

void setIn(int pin);
void setOut(int pin);

void pinHigh(int pin);
void pinLow(int pin);

void time(unsigned long ms);

int readPin(int pin);

#endif